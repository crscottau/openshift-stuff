package controllers

import (
	. "github.com/onsi/ginkgo"
)

var _ = Describe("DatabaseServer controller", func() {

})
